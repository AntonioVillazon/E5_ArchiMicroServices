import sqlite3
import pandas as pd
from pandas import DataFrame

def create_movies(conn, movie):
    """
    Create a new task
    :param conn:
    :param task:
    :return:
    """

    sql = ''' INSERT INTO MOVIES(movie_name,movie_url,movie_synopsis,movie_genre,movie_notation,movie_date)
              VALUES(?,?,?,?,?,?) '''
    cur = conn.cursor()
    cur.execute(sql, movie)
    conn.commit()
    return cur.lastrowid

def create_profils(conn, profil):
    """
    Create a new task
    :param conn:
    :param task:
    :return:
    """

    sql = ''' INSERT INTO PROFILS(name,login,password)
              VALUES(?,?,?) '''
    cur = conn.cursor()
    cur.execute(sql, profil)
    conn.commit()
    return cur.lastrowid

conn = sqlite3.connect('moviesDB.db')  # You can create a new database by changing the name within the quotes
c = conn.cursor() # The database will be saved in the location where your 'py' file is saved

# Create table - MOVIES
c.execute('''CREATE TABLE MOVIES
             ([movie_id] INTEGER PRIMARY KEY AUTOINCREMENT, [movie_name] VARCHAR, [movie_url] VARCHAR, [movie_synopsis] VARCHAR, [movie_genre] VARCHAR, [movie_notation] INTEGER, [movie_date] INTEGER)''')
          
conn.commit()


conn = sqlite3.connect('moviesDB.db')
url1=' https://www.youtube.com/watch?v=HVd9k3U2_Hw&ab_channel=MovieclipsTrailers'
url2=' https://www.youtube.com/watch?v=8JhKTZAVJQU&ab_channel=MovieclipsComingSoon'
url3=' https://www.youtube.com/watch?v=JmfKCByFFEs&ab_channel=MovieclipsTrailers'
url4=' https://www.youtube.com/watch?v=z0eOLZSqVp0&ab_channel=MovieclipsTrailers'
url5=' https://www.youtube.com/watch?v=acxUWBg_7CM&ab_channel=MovieclipsTrailers'
url6=' https://www.youtube.com/watch?v=4t7utI9yrsA&ab_channel=ONEMedia'

synopsis1=' John (Viggo Mortensen) lives with his partner, Eric (Terry Chen), and their daughter, Monica (Gabby Velis), in California, far from the traditional rural life he left behind years ago. John s father, Willis (Lance Henriksen), a headstrong man from a bygone era, lives alone on the isolated farm where John grew up. Willis is in the early stages of dementia, making running the farm on his own increasingly difficult, so John brings him to stay at his California home so that he and his sister Sarah (Linney) might help him find a place near them to relocate to. Unfortunately, their best intentions ultimately run up against Willis s adamant refusal to change his way of life in the slightest.'
synopsis2=' Chaos Walking is a young adult science fiction series written by American-British novelist Patrick Ness. It is set in a dystopian world where all living creatures can hear each other s thoughts in a stream of images, words, and sounds called Noise.'
synopsis3=' Five dangerous patients, suffering from extreme phobias at a government testing facility, are put to the ultimate test under the supervision of a crazed doctor and his quest to weaponize fear.'
synopsis4=' Jane Ciego (Iza Calzado), a successful actress, produces her own film to gain respect from the industry. During the film production, she is involved in an accident that leaves her disabled.'
synopsis5=' Prince Akeem returns to America to search for his long-lost son.'
synopsis6=' La planete la plus importante de l univers, Arrakis, est egalement appelée "Dune". Une gigantesque lutte pour le pouvoir commence autour de celle-ci, aboutissant a une guerre interstellaire.'

movie1=('Falling', url1, synopsis1, 'drama', 4, 2020)
movie2=('Chaos Walking', url2, synopsis2, 'sci-fi', 3.5, 2021)
movie3=('Phobias', url3, synopsis3, 'thriller', 3, 2021)
movie4=('Bliss', url4, synopsis4, 'drama', 2.5, 2020)
movie5=('Coming 2 America', url5, synopsis5, 'comedy', 4.5, 2021)
movie6=('Dune', url6, synopsis6, 'sci-fi', 4, 2020)
create_movies(conn, movie1)
create_movies(conn, movie2)
create_movies(conn, movie3)
create_movies(conn, movie4)
create_movies(conn, movie5)
create_movies(conn, movie6)








conn2 = sqlite3.connect("profilsDB.db")
# You can create a new database by changing the name within the quotes
c2 = conn2.cursor() # The database will be saved in the location where your 'py' file is saved

# Create table - PROFILS
c2.execute('''CREATE TABLE PROFILS
             ([id] INTEGER PRIMARY KEY AUTOINCREMENT, [name] VARCHAR, [login] VARCHAR, [password] VARCHAR)''')
conn2.commit()

conn2 = sqlite3.connect("profilsDB.db")
profil=('Yassine', 'Yassine_G', 'Goumbark1')
profil2=('Antonio', 'Antonio_V', 'Villazon1')
profil3=('Yonnel', 'Yonnel_N', 'Yonnel1')
create_profils(conn2, profil)
create_profils(conn2, profil2)
create_profils(conn2, profil3)



